import { TimeOutApp } from "@/components/TimeOutApp";

const Index = () => {
  return <TimeOutApp />;
};

export default Index;
